package com.campus.eventmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.campus.eventmanagement.model.Event;
import com.campus.eventmanagement.service.EventService;
import com.campus.eventmanagement.service.EmailService;
import com.campus.eventmanagement.registration.Registration;
import com.campus.eventmanagement.registration.RegistrationRepository;
import com.campus.eventmanagement.service.QrCodeService;

@Controller
public class EventController {

    @Autowired
    private EventService service;

    @Autowired
    private RegistrationRepository regRepo;

    @Autowired
    private EmailService emailService;

    @Autowired
    private QrCodeService qrCodeService;

@GetMapping("/registrations")
public String viewRegistrations(Model model) {
    model.addAttribute("regs", regRepo.findAll());
    
    // Create a map of Event ID to Event Name for easy lookup in the template
    java.util.Map<Long, String> eventMap = new java.util.HashMap<>();
    for (Event e : service.getAllEvents()) {
        eventMap.put(e.getId(), e.getName());
    }
    model.addAttribute("eventMap", eventMap);
    
    return "registrations";
}
    // =========================
    // STUDENT: View My Registrations
    // =========================
    @GetMapping("/my-registrations")
    public String viewMyRegistrations(Model model, java.security.Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        String email = principal.getName();
        model.addAttribute("regs", regRepo.findByEmail(email));
        
        java.util.Map<Long, String> eventMap = new java.util.HashMap<>();
        for (Event e : service.getAllEvents()) {
            eventMap.put(e.getId(), e.getName());
        }
        model.addAttribute("eventMap", eventMap);
        
        return "my-registrations";
    }

    // =========================
    // STUDENT: View all events
    // =========================
    @GetMapping("/")
    public String viewEvents(Model model) {
        model.addAttribute("events", service.getAllEvents());
        return "index";
    }

    // =========================
    // ADMIN: Dashboard
    // =========================
    @GetMapping("/admin")
    public String adminPage(Model model) {
        model.addAttribute("events", service.getAllEvents());
        model.addAttribute("event", new Event());
        return "admin";
    }

    // =========================
    // ADMIN: Save Event
    // =========================
    @PostMapping("/save")
    public String saveEvent(@ModelAttribute Event event) {
        service.saveEvent(event);
        return "redirect:/admin";
    }

    // =========================
    // ADMIN: Delete Event
    // =========================
    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id) {
        service.deleteEvent(id);
        return "redirect:/admin";
    }

    // =========================
    // STUDENT: Show Register Form
    // =========================
    @GetMapping("/register/{id}")
    public String showRegisterForm(@PathVariable Long id, Model model, java.security.Principal principal) {
        model.addAttribute("eventId", id);
        model.addAttribute("registration", new Registration());
        if (principal != null) {
            model.addAttribute("email", principal.getName());
        }
        return "register";
    }

    // =========================
    // STUDENT: Submit Registration
    // =========================
    @PostMapping("/register")
    public String registerEvent(@ModelAttribute Registration reg, Model model) {

        boolean success = service.registerForEvent(reg.getEventId(), reg.getTickets());

        if (!success) {
            model.addAttribute("error", "Not enough seats available!");
            model.addAttribute("eventId", reg.getEventId());
            return "register";
        }

        regRepo.save(reg);

        Event event = service.getEventById(reg.getEventId());
        
        String qrText = "Event: " + event.getName() + "\n" +
                        "Name: " + reg.getName() + "\n" +
                        "Tickets: " + reg.getTickets() + "\n" +
                        "ID: " + reg.getId();
                        
        String qrCodeBase64 = qrCodeService.generateQrCodeBase64(qrText, 250, 250);
        model.addAttribute("qrCodeImage", "data:image/png;base64," + qrCodeBase64);
        
        byte[] qrCodeBytes = qrCodeService.generateQrCodeImage(qrText, 250, 250);

        if (event != null) {
            emailService.sendEventRegistrationEmail(
                reg.getEmail(),
                reg.getName(),
                event.getName(),
                event.getDate(),
                event.getVenue(),
                reg.getTickets(),
                qrCodeBytes
            );
        }

        return "success";
    }
}