package com.campus.eventmanagement.controller;

import com.campus.eventmanagement.model.User;
import com.campus.eventmanagement.repository.UserRepository;
import com.campus.eventmanagement.service.OtpService;
import com.campus.eventmanagement.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private OtpService otpService;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/signup")
    public String showSignupForm() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String name, @RequestParam String email, @RequestParam String password, Model model) {
        try {
            userService.registerUser(name, email, password);
            return "redirect:/verify-otp?email=" + email;
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            return "signup";
        }
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, HttpServletRequest request, Model model) {
        boolean valid = userService.loginUser(email, password);
        if (valid) {
            Optional<User> optionalUser = userRepository.findByEmail(email);
            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                // Manually authenticate user in Spring Security Context
                UsernamePasswordAuthenticationToken authReq = new UsernamePasswordAuthenticationToken(
                        user.getEmail(), null, List.of(new SimpleGrantedAuthority(user.getRole().name()))
                );
                SecurityContext sc = SecurityContextHolder.getContext();
                sc.setAuthentication(authReq);

                HttpSession session = request.getSession(true);
                session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, sc);

                session.setAttribute("userName", user.getName());
                session.setAttribute("userRole", user.getRole().name());

                if (user.getRole() == User.Role.ADMIN) {
                    return "redirect:/admin";
                }
                return "redirect:/";
            }
        }
        model.addAttribute("error", "Invalid credentials.");
        return "login";
    }

    @GetMapping("/verify-otp")
    public String showOtpForm(@RequestParam String email, Model model) {
        model.addAttribute("email", email);
        return "otp";
    }

    @PostMapping("/verify-otp")
    public String verifyOtp(@RequestParam String email, @RequestParam String otp, HttpServletRequest request, Model model) {
        boolean success = otpService.verifyOtp(email, otp);
        if (success) {
            Optional<User> optionalUser = userRepository.findByEmail(email);
            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                // Manually authenticate user in Spring Security Context
                UsernamePasswordAuthenticationToken authReq = new UsernamePasswordAuthenticationToken(
                        user.getEmail(), null, List.of(new SimpleGrantedAuthority(user.getRole().name()))
                );
                SecurityContext sc = SecurityContextHolder.getContext();
                sc.setAuthentication(authReq);

                HttpSession session = request.getSession(true);
                session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, sc);

                // We'll set user details in session to use them in UI if needed
                session.setAttribute("userName", user.getName());
                session.setAttribute("userRole", user.getRole().name());

                if (user.getRole() == User.Role.ADMIN) {
                    return "redirect:/admin";
                }

                return "redirect:/";
            }
        }
        model.addAttribute("error", "Invalid or expired OTP");
        model.addAttribute("email", email);
        return "otp";
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
        return "redirect:/login";
    }
}
