package com.campus.eventmanagement.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())
            .headers(headers -> headers.frameOptions(frame -> frame.disable())) // Allow H2 console
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/signup", "/login", "/verify-otp", "/h2-console/**", "/css/**", "/images/**").permitAll()
                .requestMatchers("/admin/**").hasAuthority("ADMIN") // Role matches authority here since we will set it as ADMIN
                .requestMatchers("/", "/register/**").authenticated()
                .anyRequest().authenticated()
            )
            // Disable default login/logout, we handle it in AuthController manually
            .formLogin(form -> form.disable())
            .httpBasic(basic -> basic.disable())
            .exceptionHandling(ex -> ex.authenticationEntryPoint((request, response, authException) -> {
                response.sendRedirect("/login");
            }));

        return http.build();
    }
}