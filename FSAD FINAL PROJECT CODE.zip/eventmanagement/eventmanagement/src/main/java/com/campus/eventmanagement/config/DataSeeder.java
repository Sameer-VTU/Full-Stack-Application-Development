package com.campus.eventmanagement.config;

import com.campus.eventmanagement.model.Event;
import com.campus.eventmanagement.model.User;
import com.campus.eventmanagement.repository.EventRepository;
import com.campus.eventmanagement.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.findByEmail("admin@admin.com").isEmpty()) {
            User admin = new User(
                    "Admin",
                    "admin@admin.com",
                    passwordEncoder.encode("admin123"),
                    User.Role.ADMIN
            );
            admin.setVerified(true);
            userRepository.save(admin);
            System.out.println("Default Admin user created: admin@admin.com / admin123");
        }

        if (eventRepository.count() == 0) {
            Event e1 = new Event();
            e1.setName("Annual Sports Meet");
            e1.setDepartment("Physical Education");
            e1.setType("Sports");
            e1.setDate("2026-10-15");
            e1.setVenue("Main Ground");
            e1.setAvailableSeats(500);
            e1.setImageUrl("/images/sports.png");

            Event e2 = new Event();
            e2.setName("Global Hackathon");
            e2.setDepartment("Computer Science");
            e2.setType("Hackathon");
            e2.setDate("2026-11-05");
            e2.setVenue("Tech Lab 1");
            e2.setAvailableSeats(100);
            e2.setImageUrl("/images/hackathon.png");

            Event e3 = new Event();
            e3.setName("Campus Treasure Hunt");
            e3.setDepartment("Student Council");
            e3.setType("Treasure Hunt");
            e3.setDate("2026-09-20");
            e3.setVenue("Campus Wide");
            e3.setAvailableSeats(200);
            e3.setImageUrl("/images/treasure_hunt.png");

            Event e4 = new Event();
            e4.setName("BGMI Championship");
            e4.setDepartment("Gaming Club");
            e4.setType("Mobile Game Event");
            e4.setDate("2026-12-01");
            e4.setVenue("Auditorium");
            e4.setAvailableSeats(150);
            e4.setImageUrl("/images/bgmi.png");

            eventRepository.saveAll(List.of(e1, e2, e3, e4));
            System.out.println("Default Events created.");
        }
    }
}
