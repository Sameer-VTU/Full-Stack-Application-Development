package com.campus.eventmanagement.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Async
    public void sendWelcomeEmail(String toEmail, String userName) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setSubject("Welcome to Campus Events!");

            String htmlBody = "<div style='font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f9; color: #333;'>"
                    + "<div style='max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);'>"
                    + "<h2 style='color: #4f46e5; text-align: center;'>Welcome to Campus Events!</h2>"
                    + "<p style='font-size: 16px;'>Hello <strong>" + userName + "</strong>,</p>"
                    + "<p style='font-size: 16px; line-height: 1.5;'>Your account has been successfully created. We're thrilled to have you on board!</p>"
                    + "<p style='font-size: 16px; line-height: 1.5;'>Dive in to explore and register for exciting upcoming events happening on campus.</p>"
                    + "<br/><hr style='border: none; border-top: 1px solid #eee;'/>"
                    + "<p style='font-size: 14px; color: #888; text-align: center;'>Best regards,<br/>Campus Events Team</p>"
                    + "</div></div>";

            helper.setText(htmlBody, true);
            mailSender.send(message);

        } catch (MessagingException e) {
            System.err.println("Failed to send welcome email: " + e.getMessage());
        }
    }

    @Async
    public void sendOtpEmail(String toEmail, String otp) {
        System.out.println("=================================================");
        System.out.println("OTP for " + toEmail + " is: " + otp);
        System.out.println("=================================================");
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setSubject("Your Campus Events Login OTP");

            String htmlBody = "<div style='font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f9; color: #333;'>"
                    + "<div style='max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);'>"
                    + "<h2 style='color: #4f46e5; text-align: center;'>Account Verification</h2>"
                    + "<p style='font-size: 16px; text-align: center;'>Please use the following One-Time Password (OTP) to complete your verification process:</p>"
                    + "<div style='text-align: center; margin: 30px 0;'>"
                    + "<span style='display: inline-block; padding: 15px 30px; font-size: 24px; font-weight: bold; color: #4f46e5; background: #eff6ff; border-radius: 8px; border: 2px dashed #4f46e5; letter-spacing: 5px;'>" + otp + "</span>"
                    + "</div>"
                    + "<p style='font-size: 14px; text-align: center; color: #666;'>This OTP is valid for 5 minutes. Please do not share it with anyone.</p>"
                    + "<br/><hr style='border: none; border-top: 1px solid #eee;'/>"
                    + "<p style='font-size: 14px; color: #888; text-align: center;'>Best regards,<br/>Campus Events Team</p>"
                    + "</div></div>";

            helper.setText(htmlBody, true);
            mailSender.send(message);

        } catch (MessagingException e) {
            System.err.println("Failed to send OTP email: " + e.getMessage());
        }
    }

    @Async
    public void sendEventRegistrationEmail(String toEmail, String userName,
                                           String eventName, String eventDate,
                                           String eventVenue, int tickets, byte[] qrCodeBytes) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            // Multipart needs to be true for inline images
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setTo(toEmail);
            helper.setSubject("Event Registration Confirmed – " + eventName);

            String htmlBody = "<div style='font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f9; color: #333;'>"
                    + "<div style='max-width: 600px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);'>"
                    + "<h2 style='color: #10b981; text-align: center;'>Registration Confirmed!</h2>"
                    + "<p style='font-size: 16px;'>Hello <strong>" + userName + "</strong>,</p>"
                    + "<p style='font-size: 16px; line-height: 1.5;'>Your registration for <strong>" + eventName + "</strong> is successfully confirmed.</p>"
                    + "<div style='background-color: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #eee;'>"
                    + "<p style='margin: 5px 0;'><strong>Date:</strong> " + eventDate + "</p>"
                    + "<p style='margin: 5px 0;'><strong>Venue:</strong> " + eventVenue + "</p>"
                    + "<p style='margin: 5px 0;'><strong>Tickets Booked:</strong> " + tickets + "</p>"
                    + "</div>"
                    + "<p style='font-size: 16px; text-align: center;'><strong>Your Entry Pass</strong></p>"
                    + "<div style='text-align: center; margin: 20px 0;'>"
                    + "<img src='cid:qrcode' alt='Event QR Code' style='border: 2px solid #eaeaea; border-radius: 8px; padding: 10px; width: 200px; height: 200px;'/>"
                    + "<p style='font-size: 12px; color: #888; margin-top: 5px;'>Please present this QR code at the entrance.</p>"
                    + "</div>"
                    + "<br/><hr style='border: none; border-top: 1px solid #eee;'/>"
                    + "<p style='font-size: 14px; color: #888; text-align: center;'>We look forward to seeing you there!<br/>Best regards,<br/>Campus Events Team</p>"
                    + "</div></div>";

            helper.setText(htmlBody, true);
            
            // Attach the inline QR Code
            if (qrCodeBytes != null && qrCodeBytes.length > 0) {
                helper.addInline("qrcode", new ByteArrayResource(qrCodeBytes), "image/png");
            }

            mailSender.send(message);

        } catch (MessagingException e) {
            System.err.println("Failed to send registration confirmation email: " + e.getMessage());
        }
    }
}
