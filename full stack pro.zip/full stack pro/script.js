let user = {};
let selectedPlan = "";
let likes = 0;

/* Scroll Progress */
window.onscroll = () => {
  let scroll = document.documentElement.scrollTop;
  let height =
    document.documentElement.scrollHeight -
    document.documentElement.clientHeight;
  progressBar.style.width = (scroll / height) * 100 + "%";
};

/* Register */
function register() {
  if (!regName.value || !regEmail.value || !regPass.value) {
    regMsg.innerText = "Please fill all fields";
    return;
  }

  user = {
    name: regName.value,
    email: regEmail.value,
    password: regPass.value
  };

  localStorage.setItem("user", JSON.stringify(user));
  registerBox.classList.add("hide");
  loginBox.classList.remove("hide");
}

/* Login */
function login() {
  let saved = JSON.parse(localStorage.getItem("user"));

  if (loginEmail.value !== saved.email) {
    loginMsg.innerText = "Email not found";
    return;
  }

  if (loginPass.value !== saved.password) {
    loginMsg.innerText = "❌ Wrong password";
    return;
  }

  user = saved;
  userName.innerText = user.name;
  userBar.classList.remove("hide");

  loginBox.classList.add("hide");
  subscriptionBox.classList.remove("hide");
}

/* Plan */
function selectPlan(plan) {
  selectedPlan = plan;
  subscriptionBox.classList.add("hide");
  paymentBox.classList.remove("hide");
  payDetails.innerText = "Hello " + user.name + ", selected " + plan + " plan";
}

/* Payment */
function pay() {
  paymentBox.classList.add("hide");
  contentBox.classList.remove("hide");
  showContent();
}

/* Content */
function showContent() {
  let html = `<h3 style="grid-column:1/-1">Welcome ${user.name}</h3>`;

  // Images (30)
  for (let i = 1; i <= 30; i++) {
    html += `
      <div class="item" data-title="image${i}">
        <span class="like" onclick="like()">❤️</span>
        <img src="https://picsum.photos/400/300?random=${i}">
      </div>`;
  }

  // Videos (20)
  if (selectedPlan !== "Basic") {
    for (let i = 1; i <= 20; i++) {
      html += `
        <div class="item" data-title="video${i}">
          <span class="like" onclick="like()">❤️</span>
          <video controls>
            <source src="https://www.w3schools.com/html/mov_bbb.mp4">
          </video>
        </div>`;
    }
  }

  // Premium extra
  if (selectedPlan === "Premium") {
    html += `<p style="grid-column:1/-1">🌟 Premium Exclusive Content Enabled</p>`;
  }

  contentArea.innerHTML = html;
}

/* Like */
function like() {
  likes++;
  likeCount.innerText = likes;
}

/* Search */
function searchContent() {
  let q = searchBox.value.toLowerCase();
  document.querySelectorAll(".item").forEach(item => {
    item.style.display =
      item.dataset.title.includes(q) ? "block" : "none";
  });
}

/* Logout */
function logout() {
  location.reload();
}